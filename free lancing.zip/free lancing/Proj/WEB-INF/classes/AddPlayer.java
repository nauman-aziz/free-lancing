import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;


public class AddPlayer extends HttpServlet {
  
  //Process the HTTP Get request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  
	
    
	// get PrintWriter object
	PrintWriter out = response.getWriter();
	// this will view data


   /* out.println("<html>");
    out.println("<head><title>Response</title></head>");
    out.println("<form action=\"sbean.jsp\"">);
	out.println("Name <input type=\"text\" name=\"name\">");
	out.println("<br>Age <input type=\"text\" name=\"age\">");
	out.println("<br>Email <input type=\"text\" name=\"email\">");
	out.println("<br><input type=\"submit\" value=\"Send\">");
	out.println("</form>");
	*/
	out.println("</body></html>");

   

  }

}
