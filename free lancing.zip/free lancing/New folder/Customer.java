
public class Customer {
	private int cid,payment_method;
	private String cname,cphone;
	
	public Customer() {
		super();
		
	}

	public Customer(int cid, int payment_method, String cname, String cphone) {
		super();
		this.cid = cid;
		this.payment_method = payment_method;
		this.cname = cname;
		this.cphone = cphone;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public int getPayment_method() {
		return payment_method;
	}

	public void setPayment_method(int payment_method) {
		this.payment_method = payment_method;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCphone() {
		return cphone;
	}

	public void setCphone(String cphone) {
		this.cphone = cphone;
	}
	
	

}
