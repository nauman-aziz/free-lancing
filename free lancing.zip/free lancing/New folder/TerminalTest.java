
import java.util.*;
import java.sql.*;
public class TerminalTest {
    

     public static void main(String[] args) throws Exception{
    	 Store store=new Store();
		while(true)
		{
				System.out.println("Select option : ");
				System.out.println("1 to display data of all food items with price ! ");
				System.out.println("2 to display data of all customers who order the food ! ");
				System.out.println("3 to display total bill of credit card customers ! : ");
				System.out.println("4 to display total bill of debit card customers ! : ");
				System.out.println("5 to display total bill of cash on delivery customers ! : ");
				System.out.println("6 to Exit ! : ");
				
			
			Scanner inp = new Scanner(System.in);
		   int option = inp.nextInt();
		   switch(option)
		   {
			   case 1 :store.displayAllFood();
			   break;
			   
			   case 2 :store.displayAllCustomers();
			   break;
			   
			   case 3 :store.billOfCreditCard();
			   break;
			   
			   case 4 :store.billOfDebitCard();
			   break;
			   
			   case 5 :store.billOnCash();
			   break;
			   case  6:System.out.println("Good bye");
			   System.exit(0); 
			  default:System.out.println("invalid option please select again\n");break; 
			   
		   }
			
		}
     
    }
    
}

