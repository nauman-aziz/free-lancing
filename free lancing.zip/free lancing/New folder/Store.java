
import java.util.*;
import java.sql.*;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class Store {

	  public void createCustomer()throws Exception{
	       try{
	           Class.forName("com.mysql.jdbc.Driver");
	           String url = "jdbc:mysql://127.0.0.1/onlinestore";
	           Connection con=DriverManager.getConnection(url,"root","");
	           Statement st=con.createStatement();

	           Customer customer = new Customer();
	           Scanner scanner = new Scanner(System.in);
	           System.out.print("Please enter id of customer       :");
	           customer.setCid(scanner.nextInt());
	           System.out.print("Please enter name of customer       :");
	           customer.setCname(scanner.nextLine());
	           System.out.print("Please enter phone no. of customer       :");
	           customer.setCphone(scanner.nextLine());        
	           String query="insert into customers (cid , cname , cphone , payment_method) values('"+customer.getCid()+"' , '"+customer.getCname()+"' , '"+customer.getCphone()+"' , '"+customer.getPayment_method()+"')  ";
	           int rs = st.executeUpdate( query );
	           System.out.println(rs);		
	           if(rs>0){
	                JOptionPane optionPane = new JOptionPane("customer created Successfully", JOptionPane.INFORMATION_MESSAGE);    
	                JDialog dialog = optionPane.createDialog("Customer Created");
	                dialog.setAlwaysOnTop(true);
	                dialog.setVisible(true);
	                System.out.println("Customer created successfully" );
	           }
	           else{
	                JOptionPane optionPane = new JOptionPane("No such User exists", JOptionPane.ERROR_MESSAGE);    
	                JDialog dialog = optionPane.createDialog("Error");
	                dialog.setAlwaysOnTop(true);
	                dialog.setVisible(true);   
	                System.out.println("couldn't create account" );
	           }

	       }catch(SQLException e){
	           System.out.println("EXCEPTION THROWN " );
	           e.printStackTrace();
	       }     

	    }

	    public void displayAllFood() throws Exception{
	    	try{
	            Class.forName("com.mysql.jdbc.Driver");
	            String url = "jdbc:mysql://127.0.0.1/onlinestore";
	            Connection con=DriverManager.getConnection(url,"root","");
	            Statement st=con.createStatement();

	            Scanner scanner = new Scanner(System.in);
	            String query = "SELECT * FROM food_items";
	           
	            ResultSet resultSet = st.executeQuery( query );
	            while(resultSet.next()){
	            	int fid = resultSet.getInt("fid");
	                String fname = resultSet.getString("fname");
	                double fprice = resultSet.getDouble("fprice");
	                System.out.format("%s, %s, %s\n", fid, fname, fprice);
	            }
	           } catch (SQLException e) {
	               e.printStackTrace();
	           }
	    	
	    	
	    }

	public void displayAllCustomers() throws Exception{
		try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/onlinestore";
            Connection con=DriverManager.getConnection(url,"root","");
            Statement st=con.createStatement();

            Scanner scanner = new Scanner(System.in);
            String query = "SELECT * FROM customers ";
           
            ResultSet resultSet = st.executeQuery( query );
            while(resultSet.next()){
            	int id = resultSet.getInt("cid");
                String name = resultSet.getString("cname");
                String phone = resultSet.getString("cphone");
                System.out.format("%s, %s, %s\n", id, name, phone);
            }
           } catch (SQLException e) {
               e.printStackTrace();
           }
    	
		
	}    
	public void billOfCreditCard() throws Exception{
		try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/onlinestore";
            Connection con=DriverManager.getConnection(url,"root","");
            Statement st=con.createStatement();

            Scanner scanner = new Scanner(System.in);
            String query = "SELECT * FROM customers where payment_method = 1";
           
            ResultSet resultSet = st.executeQuery( query );
            while(resultSet.next()){
            	int id = resultSet.getInt("cid");
                String name = resultSet.getString("cname");
                String phone = resultSet.getString("cphone");
                System.out.format("%s, %s, %s\n", id, name, phone);
            }
            query = "SELECT * FROM 'orrder' where method = 1";
            
            resultSet = st.executeQuery( query );
            if(resultSet.next()){
            	int tb = resultSet.getInt("totalbill");
                int dis = calculateBill(10,tb);
                System.out.println("total bill");
                System.out.format("%s, %s, %s\n", dis);
            }
            
           } catch (SQLException e) {
               e.printStackTrace();
           }
		
	}
	public void billOfDebitCard() throws Exception{
		try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/onlinestore";
            Connection con=DriverManager.getConnection(url,"root","");
            Statement st=con.createStatement();

            Scanner scanner = new Scanner(System.in);
            String query = "SELECT * FROM customers where payment_method = 2";
           
            ResultSet resultSet = st.executeQuery( query );
            while(resultSet.next()){
            	int id = resultSet.getInt("cid");
                String name = resultSet.getString("cname");
                String phone = resultSet.getString("cphone");
                System.out.format("%s, %s, %s\n", id, name, phone);
            }
            query = "SELECT * FROM 'orrder' where method = 1";
            
            resultSet = st.executeQuery( query );
            if(resultSet.next()){
            	int tb = resultSet.getInt("totalbill");
                int dis = calculateBill(7,tb);
                System.out.println("total bill");
                System.out.format("%s, %s, %s\n", dis);
            }
           } catch (SQLException e) {
               e.printStackTrace();
           }
		
	}

	public void billOnCash() throws Exception{
		try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/onlinestore";
            Connection con=DriverManager.getConnection(url,"root","");
            Statement st=con.createStatement();

            Scanner scanner = new Scanner(System.in);
            String query = "SELECT * FROM customers where payment_method = 3";
           
            ResultSet resultSet = st.executeQuery( query );
            while(resultSet.next()){
            	int id = resultSet.getInt("cid");
                String name = resultSet.getString("cname");
                String phone = resultSet.getString("cphone");
                System.out.format("%s, %s, %s\n", id, name, phone);
            }
            query = "SELECT * FROM 'orrder' where method = 3";
            
            resultSet = st.executeQuery( query );
            if(resultSet.next()){
            	int tb = resultSet.getInt("totalbill");
                int dis = calculateBill(5,tb);
                System.out.println("total bill");
                System.out.format("%s, %s, %s\n", dis);
            }
           } catch (SQLException e) {
               e.printStackTrace();
           }
		
	}
	
	public int calculateBill(int percentDiscount ,int original_price) {
		int discounted_price = original_price - (original_price * percentDiscount / 100);
		return discounted_price+100;
		
	}
}
