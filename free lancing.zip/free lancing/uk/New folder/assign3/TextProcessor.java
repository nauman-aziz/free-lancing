/**
 * Keep track of words.
 *
 * @author 
 * @version 
 */
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class TextProcessor
{    
    /**
     * Constructor for objects of class TextProcessor
     */
    private String dat,temp,remember;
    
    public TextProcessor()
    {
    }
    
    /**
     * Add a word to the processor.
     * @param word the word to be added.
     */
    public void setStr(String s){
        this.temp +=" "+s;
    }
    public void addWord(String word)
    {   
        this.dat +=" "+word;  
        
    }
    
    private int countOccurences(String str, String word)  
    { 
        // split the string by spaces in a 
        String a[] = str.split(" "); 
      
        // search for pattern in a 
        int count = 0; 
        for (int i = 0; i < a.length; i++)  
        { 
        // if match found increase count 
        if (word.equals(a[i])) 
            count++; 
        } 
      
        return count; 
    } 
    /**
     * Get the number of times the given word has added
     * via addWord.
     * @param word The word to be looked up.
     * @return How many times the word has been added.
     */
    public int howMany(String word)
    {
        
        int c = countOccurences(temp ,word);
        return c;
        
    }
   
    
    /**
     * Return the number of distinct words str is a
     * suffix of in the words added so far.
     * 
     * It counts as a suffix if a word ends with
     * str but str does not also match the whole word.
     * For instance: "thing" matches the following 3 examples:
     *     "something" "nothing" "thing"
     * but only the first two qualify as proper suffix matches.
     * 
     * Each word that contains the suffix must only be counted once,
     * so if "something" has been added 3 times, that only counts
     * as 1 match.
     * @param str The suffix to look for.
     * @return the number of distinct words with the given suffix. 
     */
    public int suffixCount(String str)
    {
        int count=0;
        for (String word : dat.split(" ")) {
            if(word.equalsIgnoreCase(str)){
                continue;
            }
            if(isSuffix(str,word)){
                count++;
            }
        }
        return count;
    }
    private static boolean isSuffix(String s1, String s2) 
    { 
        
        int n1 = s1.length(), n2 = s2.length(); 
        if (n1 > n2) 
        return false; 
        for (int i=0; i<n1; i++){
            if (s1.charAt(n1 - i - 1) != s2.charAt(n2 - i - 1)) 
                return false; 
        } 
        
         
        return true; 
    } 
    /**
     * Count the number of distinct case-insensitive anagrams
     * of the given word that have been added to the processor. 
     * 
     * An anagram consists of exactly the same number of
     * letters as the given word, each character occurring
     * the same number of times. It does not count as an
     * anagram if the two words are already identical.
     * 
     * For instance: "and" is an anagram of "Dan" but
     *               "nan" is neither an anagram of "naan" nor "nan".
     *
     * @param word The word to be compared.
     * @return the number of case-insensitive anagrams
     *         of word.
     */
    private  int countAnagrams(String text, String word) 
    { 
        int N = text.length(); 
        int n = word.length(); 
  
        // Initialize result 
        int res = 0; 
  
        for (int i = 0; i <= N - n; i++) { 
  
            String s = text.substring(i, i + n); 
  
            // Check if the word and substring are 
            // anagram of each other. 
            if (araAnagram(word, s)) 
                res++; 
        } 
      
        return res; 
    } 
        // Function to find if two strings are equal 
    private  boolean araAnagram(String s1, 
                              String s2) 
    { 
        // converting strings to char arrays 
        char[] ch1 = s1.toCharArray(); 
        char[] ch2 = s2.toCharArray(); 
     
        // sorting both char arrays 
        Arrays.sort(ch1); 
        Arrays.sort(ch2); 
  
        // Check for equality of strings 
        if (Arrays.equals(ch1, ch2)) {
        
            String str = new String(ch1);
            if(remember!=null){
                if(remember.contains(str)){
                return false;
                }else{
                remember +=ch1;
                }
            }
            
            return true; 
        }    
        else
            return false; 
    }
    public int anagramCount(String word)
    {
        return countAnagrams(dat, word);
        
    }
    
}
