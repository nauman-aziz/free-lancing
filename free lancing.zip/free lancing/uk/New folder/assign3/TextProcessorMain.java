import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * A simple 'driver' for the TextProcessor class.
 * 
 * Split a 'document' into individual words and pass them
 * to a TextProcessor to be analysed.
 * 
 * In this example, the 'document' is a String literal in
 * the main method, but this can easily be changed to the
 * contents of an external file by passing a filename as
 * a parameter to the main method.
 * 
 * Print a few sample statistics.
 *
 * @author David J. Barnes
 * @version 2020.12.05
 */
public class TextProcessorMain
{
    public static void main(String[] args) 
        throws Exception
    {
        // Set up the document to be processed.
        String document;
        if(args.length == 1) {
            File text = new File(args[0]);
            document = Files.lines(text.toPath()).collect(Collectors.joining(" ")).trim();                    
        }
        else {
            document =
                "Dan saw it was time to take the risk and visit his Nan." + " " +
                "The thing is, there was nothing to be lost," + " " +
                "because something was bound to happen.";
        }
        
        // Extract the individual words.
        String[] words = document.split("[ ,.;:?]+");
        System.out.println(words.length + " words to analyse.");
        
        
        TextProcessor processor = new TextProcessor();
        
        for(String word : words){
           processor.setStr(word); 
        }
        for(String word : words) {
            processor.addWord(word);
        }
        
        // Check some results.
        for(String word : List.of("thing", "to", "Friday", "and", "the")) {
            System.out.println(word);
            System.out.println("    how many: " + processor.howMany(word));
            System.out.println("    suffixes: " + processor.suffixCount(word));
            System.out.println("    anagrams: " + processor.anagramCount(word));
        }
    }
}
