package lib;

import java.util.*;

public class Register implements Iterable<Name>{

	private ArrayList<Name> names;
	private int capacity;

	public Register(int capacity){
		this.capacity = capacity;
		names = new ArrayList<Name>(capacity);
	}
	
	public Register() {
		// TODO Auto-generated constructor stub
	}

	public Iterator<Name> iterator(){
		return this.names.iterator();
	}

	public void addNames(ArrayList<Name> arr){
		if (this.names.size() == arr.size())
			this.names = arr;
	}

	public Name getName(int index){
		return (Name)names.get(index);
	}
	
	public void addName(Name name){
		if(this.names.size() < capacity){
			names.add(name);
			capacity--;
		}
	}

	public void sortRegister() {
		Collections.sort(names);
	}

	public Boolean isRegisterEmpty(){
		return (sizeOfRegister() == 0);
	}

	public int sizeOfRegister(){
		return names.size();
	}

	public int getRoomCapacity(){
		return (capacity - names.size());
	}

	public Name removeName(int i) {
		Name n = names.get(i);
		names.remove(i);
		return n;
	}

	public void clearRegister() {
		names.clear();
		
	}

	public boolean searchRegisterByFirstNameInitial(char c) {
		for(Name n : names) {
			if(c == n.getFirstName().charAt(0)) {
				return true;
			}
		}
		
		return false;
	}

	public int countFirstNameOccurrences(String string) {
		int count =0;
		for(Name n : names) {
			if(string.equals( n.getFirstName())) {
				count++;
			}
		}
		return count;
	}
}

