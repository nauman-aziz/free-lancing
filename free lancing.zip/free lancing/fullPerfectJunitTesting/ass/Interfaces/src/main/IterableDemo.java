package main;

import lib.polymorphism.Die;
import lib.polymorphism.MultipleDice;

public class IterableDemo {

	public static void main(String[] args) {
		MultipleDice dice = new MultipleDice();
		for (Die d : dice) {
	        System.out.println(d);
		}

		
		dice.forEach(d -> System.out.println(d));
	}
}
