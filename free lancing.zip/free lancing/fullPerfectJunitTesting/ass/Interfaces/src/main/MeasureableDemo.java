package main;
import lib.measurable.*;

public class MeasureableDemo {

	public static void main(String[] args) {
		DataAnalysis<Song> da = new DataAnalysis<Song>();
		System.out.println(da.sum());
		System.out.println(da.avg());
		
		DataAnalysis<Name> da1 = new DataAnalysis<Name>();
		System.out.println(da1.sum());
		System.out.println(da1.avg());
	}
}
