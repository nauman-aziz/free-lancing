package lib.measurable;
import java.util.*;
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;


public class DataAnalysis<E extends Measureable> {

	private List<E> objects;

	public DataAnalysis() {
		objects = new ArrayList<>();
	}

	public void addMeasurable(E m) {
		objects.add(m);
	}

	public int sum() {
		return objects.stream().mapToInt(m -> m.getMeasure()).sum();
	}
	
	public String toString() {
		return "DataAnalysis[objects= " + objects + "]";
	}
	
	public double avg() {
		return objects.stream().mapToInt(m -> m.getMeasure()).average().getAsDouble();
	}
	
	public int min() {
		return objects.stream().mapToInt(m -> m.getMeasure()).min().getAsInt();
	}
	
	public int max() {
		return objects.stream().mapToInt(m -> m.getMeasure()).max().getAsInt();
	}
}
