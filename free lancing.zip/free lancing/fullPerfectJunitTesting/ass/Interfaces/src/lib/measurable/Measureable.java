package lib.measurable;

public interface Measureable {

	public int getMeasure();
}
