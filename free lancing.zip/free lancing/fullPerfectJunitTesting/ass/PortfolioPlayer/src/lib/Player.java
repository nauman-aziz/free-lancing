package lib;
import java.util.*;
import java.lang.*;

public class Player implements Comparable{
	private Name name;
	private String gamerTag;
	private Rollable rollable;
	
	Player(){
		super();
		this.name = new Name();
		this.gamerTag = "";
		this.rollable = new PairOfDice();
	}
	public String toString(){
		return "Player:["+name.toString() + gamerTag.toString() + rollable.toString()+"]";
		
	}
	Player(String name, String gamerTag, Rollable rollable){
		this.setFullPlayerName(name);
		this.gamerTag = gamerTag;
		this.rollable = new PairOfDice();
	}
	
	
	
	public Player(Name n, String gt) {
		this.name=n;
		this.gamerTag = gt;
		this.rollable = new PairOfDice();
	
	}

	public Player(Name n, String gt, Rollable r) {
		this.name = n;
		this.gamerTag = gt;
		this.rollable = r;
	}

	public String getGamerTag() {
		return gamerTag;
	}
	
	public String getFamilyName() {
		return this.name.getFamilyName();
	}
	
	public String getFirstName() {
		return this.name.getFirstName();
	}

	public Rollable getRollable() {
		return this.rollable;
	}
	
	/** Setting the player name by splitting the input string into fist name and family name */
	public void setFullPlayerName(String input) {
		String[] tokens = input.split(" ");
		if(tokens.length == 2) {
			this.name.setFirstName( tokens[0].substring(0, 1).toUpperCase() + tokens[0].substring(1).toLowerCase());
			this.name.setFamilyName( tokens[1].substring(0, 1).toUpperCase() + tokens[1].substring(1).toLowerCase());
		} 
		else
			System.out.println("Invalid Input!");	
	}
	
	/** Generating gamer tag by appending first name and family name in lower case and adding the input integer to it after reversing it */
	public void generateGamerTag(int input) {
		if(input < 1 || input > 100)
			System.out.println("Invalid Input!");
		else {
			this.gamerTag = new StringBuilder(this.name.getFirstName().toLowerCase() + this.name.getFamilyName().toLowerCase()).reverse().toString();
			this.gamerTag = this.gamerTag + String.valueOf(input);
		}			
	}

	@Override
	public int compareTo(Object o) {
		Player temp = (Player)o;
		if(this.name.compareTo(temp.getName()) != 0)
			return this.name.compareTo(temp.getName());
		else
			return this.gamerTag.compareTo(temp.getGamerTag());
	}

	public Name getName() {
	
		return name;
	}

	public void setGamerTag(String gt) {
		this.gamerTag = gt;
		
	}

	public Name setName(Name n) {
		this.name = n;
		return n;
	}

	public void rollDice() {
		this.rollable.roll();
	}

	public int getDiceScore() {
		return this.rollable.getScore();
	}	
}
