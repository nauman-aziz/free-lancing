package main;

import java.util.*;

import lib.Player;

public class PlayerApp {

	public static String execute(ArrayList<Player> participants, int number) {
		
		String result = "";
		for(int i = 0; i < participants.size(); i++) {
			Player temp = participants.get(i);
			if(temp.getGamerTag().contains(temp.getFamilyName()) && temp.getGamerTag().contains(String.valueOf(number))) {
				result += temp.getFirstName() + ", " + temp.getFamilyName() + "\n";
			}
		}
		
		return result;
	}
	
}