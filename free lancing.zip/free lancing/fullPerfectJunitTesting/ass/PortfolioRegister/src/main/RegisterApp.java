package main;

import lib.Name;
import lib.Register;

public class RegisterApp {

	public static String execute(Name nm, Register regst) {	
		
		return "";
	}
}