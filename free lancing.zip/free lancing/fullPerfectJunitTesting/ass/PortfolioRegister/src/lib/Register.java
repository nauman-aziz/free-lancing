package lib;

import java.util.*;
/**
This class registers a player with it�s name in an iterabe in arraylist of type Names.
	Constructors:
		1 parameterized(int): Recieves values as parameters and initializes the arraylist of the size of given integer and sets it as a capacity.
	Functions:	
		addNames(ArralyList<Name>): Registers the given list of names by adding them to the list.
		addName(Name): Registers a single player by the given name.
		sortRegister(): Sorts the list of names.
		isRegisterEmpty(): Returns true or false if the register is empty (the list is empty).
		removeName(int): Removes the name on the given index of array.
		searchRegisterByFirstNameInitial(char): Searches the register by the given first letter of the name.
 */
public class Register implements Iterable<Name>{
	/**
	Private datamembers of the class
 	*/
	private ArrayList<Name> names;
	private int capacity;
	/**
	Public constructor of the class register and sets the capacity of current object according to the parameter and initiliazes the names datamember
	@param capacity (Capacity of the list of players)
 	*/
	public Register(int capacity){
		this.capacity = capacity;
		names = new ArrayList<Name>(capacity);
	}
	/**
	Public non-parametrized constructor of the class 
	 */
	public Register() {
		this.names = new ArrayList<Name>();
		capacity = 0;
	}
	/**
	@return the names of current object of iterator class
	 */
	public Iterator<Name> iterator(){
		return this.names.iterator();
	}
	/**
	Add names to the arraylist
	@param arr ArrayList of the names of player to be added
	 */
	public void addNames(ArrayList<Name> arr){
		if (this.names.size() == arr.size())
			this.names = arr;
	}
	/**
	Returns the name present on the index provided as parameter of the name class.
	@param index index of the player to be returned.
	@return Name object against the given index
	 */
	public Name getName(int index){
		return (Name)names.get(index);
	}
	/**
	Adds a new name to arraylist if capacity is remaining
	@param name Name Object to be added to the Register
	 */
	public void addName(Name name){
		if(this.names.size() < capacity){
			names.add(name);
			capacity--;
		}
	}
	/**
	Sort the names of the arraylist
	 */
	public void sortRegister() {
		Collections.sort(names);
	}
	/**
	checkes wether the arraylist is empty or not. Returns true if empty
	@return true or false if the register is empty
	 */
	public Boolean isRegisterEmpty(){
		return (sizeOfRegister() == 0);
	}
	/**
	@return the size of arraylist
	 */
	public int sizeOfRegister(){
		return names.size();
	}
	/**
	@return the current capacity of the arraylist
	 */
	public int getRoomCapacity(){
		return (capacity - names.size());
	}
	/**
	Removes the element of arraylist at given index the reutrns the name removed
	@param i index of the name to be removed from the register
	 */
	public Name removeName(int i) {
		Name n = names.get(i);
		names.remove(i);
		return n;
	}
	/**
	clears the arraylist
	 */
	public void clearRegister() {
		names.clear();
		
	}

	/**Searches the registrt for the playing having first character of the name equal to the character passed as parameter
	@param c first character of the name to be searched
	@return bool if the player with name having intitial character exists
	 */
	public boolean searchRegisterByFirstNameInitial(char c) {
		for(Name n : names) {
			if(c == n.getFirstName().charAt(0)) {
				return true;
			}
		}
		
		return false;
	}

	/** Counts the occurences of the names having firstname equal to the string passed as parameter 
	@param string firstName to be matched for the count of occurrences
	@return count Number of the occurences of the given string
	*/
	public int countFirstNameOccurrences(String string) {
		int count =0;
		for(Name n : names) {
			if(string.equals( n.getFirstName())) {
				count++;
			}
		}
		return count;
	}
}

